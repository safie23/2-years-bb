import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import { createClient } from '@supabase/supabase-js';

const app = express();
const port = Number(process.env.PORT || 4000);

app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_PUBLISHABLE_KEY;
const supabase = supabaseUrl && supabaseKey
  ? createClient(supabaseUrl, supabaseKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    })
  : null;

app.get('/api/health', (_req, res) => {
  res.json({ ok: true, app: 'JointCare API', timestamp: new Date().toISOString() });
});

async function requireUser(req, res, next) {
  if (!supabase) {
    return res.status(503).json({ error: 'Supabase is not configured on the server.' });
  }
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) return res.status(401).json({ error: 'Missing bearer token.' });

  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
  req.user = data.user;
  next();
}

app.get('/api/me', requireUser, (req, res) => {
  res.json({
    id: req.user.id,
    email: req.user.email,
    app: 'JointCare',
  });
});

app.use((_req, res) => res.status(404).json({ error: 'Route not found.' }));

app.listen(port, () => {
  console.log(`JointCare API running at http://localhost:${port}`);
});
