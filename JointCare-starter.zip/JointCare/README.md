# JointCare — ระบบคลินิกกระดูกและข้อ

โปรเจกต์เริ่มต้นสำหรับเรียนรู้การสร้างเว็บคลินิกกระดูกและข้อ โดยใช้:
- Frontend: React + Vite
- Authentication / Database: Supabase Auth + PostgreSQL + Row Level Security (RLS)
- Backend API: Node.js + Express
- Storage: Supabase Storage (แนะนำให้ตั้งเป็น Private สำหรับเอกสารทางการแพทย์)

> **คำเตือน:** โปรเจกต์นี้เป็น starter สำหรับการเรียนรู้ ยังไม่พร้อมใช้งานกับข้อมูลผู้ป่วยจริงจนกว่าจะตรวจสอบสิทธิ์การเข้าถึง, Storage policies, audit logs, backup, privacy/compliance และการทดสอบความปลอดภัยอย่างครบถ้วน ห้ามใส่ Supabase secret/service-role key ใน frontend

## 1. สิ่งที่ต้องติดตั้ง

1. ติดตั้ง Node.js รุ่น LTS จาก https://nodejs.org/
2. มีบัญชี Supabase ที่ https://supabase.com/
3. แตกไฟล์ ZIP แล้วเปิดโฟลเดอร์ `JointCare` ด้วย VS Code

ตรวจสอบ Node.js และ npm ใน Terminal:
```bash
node -v
npm -v
```

## 2. สร้าง Supabase project

1. เข้า Supabase และสร้างโปรเจกต์ใหม่ ตั้งชื่อ `JointCare`
2. ตั้งรหัสผ่านฐานข้อมูลและเก็บไว้ให้ปลอดภัย
3. เมื่อสร้างเสร็จ ไปที่ **Project Settings → API** (ชื่อเมนูอาจแตกต่างตามหน้าจอ)
4. คัดลอก Project URL และ publishable/anon key สำหรับการเชื่อมต่อจาก frontend
5. ห้ามนำ secret/service-role key ไปใส่ในไฟล์ frontend หรือส่งให้ผู้อื่น

## 3. สร้างตารางและ RLS

1. เปิดหน้า **SQL Editor** ใน Supabase
2. เปิดไฟล์ `supabase/schema.sql` จากโปรเจกต์นี้
3. คัดลอก SQL ทั้งหมดไปวาง แล้วกด Run
4. ตรวจสอบว่าตาราง `profiles`, `patients`, `appointments` ถูกสร้างสำเร็จ

SQL นี้เป็นนโยบายเริ่มต้นสำหรับผู้ใช้ทั่วไปเท่านั้น ยังไม่มีนโยบายสำหรับเจ้าหน้าที่คลินิก จึงยังไม่ควรนำไปใช้กับข้อมูลจริงหรือเปิดให้เจ้าหน้าที่เข้าถึงข้อมูลผู้ป่วย

## 4. ตั้งค่า Frontend

เปิด Terminal ใน VS Code แล้วรัน:
```bash
cd JointCare/frontend
npm install
cp .env.example .env.local
```

เปิด `frontend/.env.local` แล้วใส่ค่าจริง:
```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
VITE_API_URL=http://localhost:4000
```

จากนั้นเริ่มเว็บ:
```bash
npm run dev
```

เปิด URL ที่ Vite แสดง โดยปกติคือ http://localhost:5173

## 5. ตั้งค่า Backend API

เปิด Terminal ใหม่อีกหน้าต่าง แล้วรัน:
```bash
cd JointCare/backend
npm install
cp .env.example .env
```

เปิด `backend/.env` และใส่ Project URL กับ publishable/anon key เดียวกับ Supabase โปรเจกต์ของคุณ:
```env
PORT=4000
FRONTEND_ORIGIN=http://localhost:5173
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_PUBLISHABLE_KEY=YOUR_SUPABASE_PUBLISHABLE_KEY
```

เริ่ม Backend:
```bash
npm run dev
```

ทดสอบเปิด http://localhost:4000/api/health ควรเห็นสถานะ `ok: true`

## 6. ทดสอบสมัครสมาชิกและเข้าสู่ระบบ

1. เปิดเว็บที่ http://localhost:5173
2. กรอกชื่อ อีเมล และรหัสผ่าน แล้วกดสมัครสมาชิก
3. หาก Supabase ต้องยืนยันอีเมล ให้เปิดอีเมลและยืนยันก่อนเข้าสู่ระบบ (ขึ้นอยู่กับการตั้งค่า Auth)
4. ลองออกจากระบบ แล้วเข้าสู่ระบบด้วยบัญชีเดิม
5. เมื่อเข้าสู่ระบบแล้ว หน้าเว็บจะแสดงสถานะบัญชีที่เชื่อมต่อ

## 7. สร้าง Storage bucket สำหรับไฟล์ภาพทางการแพทย์ (ยังไม่เปิดใช้อัปโหลด)

1. ไปที่ **Storage** ใน Supabase
2. สร้าง bucket ชื่อ `medical-images`
3. ตั้งเป็น **Private**
4. อย่าเปิด public access และอย่าอัปโหลดข้อมูลผู้ป่วยจริงจนกว่าจะกำหนดและทดสอบ Storage RLS policies ที่เหมาะสม

## 8. โครงสร้างโปรเจกต์

```text
JointCare/
├── README.md
├── frontend/
│   ├── .env.example
│   ├── package.json
│   ├── index.html
│   └── src/
│       ├── App.jsx
│       ├── main.jsx
│       ├── style.css
│       └── lib/
│           └── supabase.js
├── backend/
│   ├── .env.example
│   ├── package.json
│   └── src/
│       └── server.js
└── supabase/
    └── schema.sql
```

## 9. แก้ปัญหาเบื้องต้น

- `npm: command not found`: ติดตั้ง Node.js LTS แล้วปิด/เปิด Terminal ใหม่
- Supabase URL/key error: ตรวจสอบ `.env.local` และ `backend/.env` ว่าไม่มีช่องว่างหรืออัญประกาศเกินจำเป็น
- แก้ค่า env แล้วเว็บยังใช้ค่าเดิม: หยุด Vite ด้วย `Ctrl + C` แล้วรัน `npm run dev` ใหม่
- Backend ต่อไม่ได้: ตรวจว่า Backend รันอยู่และเปิด `http://localhost:4000/api/health`
- สมัครสมาชิกแล้วไม่เข้าได้ทันที: ตรวจอีเมลยืนยันและ Auth settings ใน Supabase
- ห้ามส่งไฟล์ `.env.local` หรือ `.env` ที่มีค่าจริงขึ้น Git หรือแนบให้ผู้อื่น

## 10. ขอบเขตของเวอร์ชันนี้

มีหน้าเว็บเริ่มต้น, สมัครสมาชิก/เข้าสู่ระบบผ่าน Supabase, API ตรวจสอบ token และ schema ฐานข้อมูลพื้นฐาน ยังไม่ได้ทำระบบนัดหมายเต็มรูปแบบ, dashboard แพทย์, LINE/SMS, QR check-in, payment gateway, medical image upload, triage ทางคลินิก หรือ role policies สำหรับเจ้าหน้าที่
