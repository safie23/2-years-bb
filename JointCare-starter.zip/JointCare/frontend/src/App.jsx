import { useEffect, useState } from 'react';
import {
  Activity, ArrowRight, Bone, CalendarDays, CheckCircle2, Clock3,
  HeartPulse, LogIn, LogOut, Menu, ShieldCheck, Stethoscope, UserRound, X
} from 'lucide-react';
import { supabase } from './lib/supabase';

const specialties = [
  { icon: Bone, title: 'กระดูกและข้อ', desc: 'ตรวจประเมินอาการปวดกระดูกและข้อต่อ' },
  { icon: Activity, title: 'กระดูกสันหลัง', desc: 'ดูแลอาการปวดหลังและคอ' },
  { icon: HeartPulse, title: 'เวชศาสตร์การกีฬา', desc: 'ฟื้นฟูการบาดเจ็บจากการออกกำลังกาย' },
  { icon: Stethoscope, title: 'เข่าและไหล่', desc: 'ประเมินการเคลื่อนไหวและอาการบาดเจ็บ' },
];

export default function App() {
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authMode, setAuthMode] = useState('login');
  const [showAuth, setShowAuth] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [notice, setNotice] = useState('');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setLoading(false);
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setLoading(false);
    });
    return () => listener.subscription.unsubscribe();
  }, []);

  async function submitAuth(event) {
    event.preventDefault();
    if (!supabase) {
      setNotice('กรุณาตั้งค่า VITE_SUPABASE_URL และ VITE_SUPABASE_PUBLISHABLE_KEY ในไฟล์ .env.local ก่อน');
      return;
    }
    setBusy(true);
    setNotice('');
    try {
      if (authMode === 'signup') {
        const { error } = await supabase.auth.signUp({
          email: form.email,
          password: form.password,
          options: { data: { full_name: form.name } },
        });
        if (error) throw error;
        setNotice('สมัครสมาชิกแล้ว หากระบบขอให้ยืนยันอีเมล กรุณาตรวจสอบกล่องจดหมายของคุณ');
      } else {
        const { error } = await supabase.auth.signInWithPassword({
          email: form.email,
          password: form.password,
        });
        if (error) throw error;
        setNotice('เข้าสู่ระบบสำเร็จ');
        setShowAuth(false);
      }
    } catch (error) {
      setNotice(error.message || 'ดำเนินการไม่สำเร็จ กรุณาลองใหม่');
    } finally {
      setBusy(false);
    }
  }

  async function signOut() {
    if (!supabase) return;
    const { error } = await supabase.auth.signOut();
    setNotice(error ? error.message : 'ออกจากระบบแล้ว');
  }

  return (
    <div className="app-shell">
      <header className="site-header">
        <a className="brand" href="#home" aria-label="JointCare home">
          <span className="brand-mark"><Bone size={25} /></span>
          <span><strong>JointCare</strong><small>ORTHOPEDIC CLINIC</small></span>
        </a>
        <button className="menu-toggle" onClick={() => setMobileMenu(!mobileMenu)} aria-label="เปิดเมนู">
          {mobileMenu ? <X /> : <Menu />}
        </button>
        <nav className={mobileMenu ? 'nav-links open' : 'nav-links'}>
          <a href="#services" onClick={() => setMobileMenu(false)}>บริการของเรา</a>
          <a href="#about" onClick={() => setMobileMenu(false)}>เกี่ยวกับคลินิก</a>
          <a href="#contact" onClick={() => setMobileMenu(false)}>ติดต่อเรา</a>
        </nav>
        <div className="header-actions">
          {session ? (
            <button className="btn btn-outline" onClick={signOut}><LogOut size={17} /> ออกจากระบบ</button>
          ) : (
            <button className="btn btn-primary" onClick={() => { setShowAuth(true); setAuthMode('login'); }}>
              <LogIn size={17} /> เข้าสู่ระบบ
            </button>
          )}
        </div>
      </header>

      {notice && <div className="notice" role="status"><CheckCircle2 size={18} /> <span>{notice}</span><button onClick={() => setNotice('')} aria-label="ปิดข้อความ"><X size={16}/></button></div>}

      <main>
        <section className="hero" id="home">
          <div className="hero-copy">
            <div className="eyebrow"><span className="pulse-dot" /> ดูแลทุกการเคลื่อนไหวของคุณ</div>
            <h1>กลับมาใช้ชีวิต<br />ได้อย่าง <em>มั่นใจ</em></h1>
            <p className="hero-description">ดูแลสุขภาพกระดูกและข้ออย่างใส่ใจ ด้วยทีมผู้เชี่ยวชาญและแนวทางการรักษาที่เหมาะกับคุณ</p>
            <div className="hero-actions">
              <button className="btn btn-primary btn-large" onClick={() => { setShowAuth(true); setAuthMode('signup'); }}>
                เริ่มต้นใช้งาน <ArrowRight size={18} />
              </button>
              <a className="text-link" href="#services">สำรวจบริการ <span>↗</span></a>
            </div>
            <div className="trust-row">
              <div className="trust-icon"><ShieldCheck size={20}/></div>
              <div><strong>ใส่ใจความเป็นส่วนตัว</strong><small>ข้อมูลของคุณควรได้รับการปกป้อง</small></div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="visual-orbit orbit-one"></div><div className="visual-orbit orbit-two"></div>
            <div className="medical-art">
              <div className="art-cross">+</div>
              <div className="art-circle"><Bone size={118} strokeWidth={1.15}/></div>
              <div className="art-label label-top"><span className="label-dot"></span><div><strong>Personalized care</strong><small>ดูแลเฉพาะคุณ</small></div></div>
              <div className="art-label label-bottom"><CalendarDays size={20}/><div><strong>นัดหมายสะดวก</strong><small>จัดการได้ในที่เดียว</small></div></div>
              <div className="art-spark spark-one">✳</div><div className="art-spark spark-two">✦</div>
            </div>
            <div className="floating-note"><span><HeartPulse size={20}/></span><div><strong>Move better.</strong><small>Live healthier.</small></div></div>
          </div>
          <div className="hero-footer"><span>01 / ดูแลสุขภาพกระดูกและข้อ</span><span>CARE THAT MOVES WITH YOU <span className="footer-line"></span></span></div>
        </section>

        <section className="services section-wrap" id="services">
          <div className="section-heading">
            <div><div className="eyebrow">OUR SPECIALTIES</div><h2>ดูแลคุณในทุกการเคลื่อนไหว</h2></div>
            <p>เริ่มต้นจากการประเมินอาการ เพื่อวางแผนการดูแลที่เหมาะสมกับแต่ละบุคคล</p>
          </div>
          <div className="service-grid">
            {specialties.map(({ icon: Icon, title, desc }, index) => (
              <article className="service-card" key={title}>
                <div className="service-icon"><Icon size={25}/></div><span className="service-number">0{index + 1}</span>
                <h3>{title}</h3><p>{desc}</p><a href="#contact" aria-label={`สอบถามบริการ ${title}`}><ArrowRight size={18}/></a>
              </article>
            ))}
          </div>
        </section>

        <section className="care-banner" id="about">
          <div className="banner-symbol"><Bone size={42}/></div>
          <div><div className="eyebrow">YOUR CARE, YOUR PACE</div><h2>เริ่มดูแลตัวเองวันนี้<br/>ทีละก้าวอย่างมั่นใจ</h2></div>
          <p>JointCare เป็นจุดเริ่มต้นสำหรับจัดการข้อมูลและบริการคลินิกกระดูกและข้อในที่เดียว</p>
          <button className="btn btn-light" onClick={() => { setShowAuth(true); setAuthMode('signup'); }}>สร้างบัญชีผู้ใช้ <ArrowRight size={17}/></button>
        </section>

        <section className="contact-row section-wrap" id="contact">
          <div><div className="eyebrow">GET IN TOUCH</div><h2>มีคำถามเกี่ยวกับบริการ?</h2><p>ติดต่อคลินิกเพื่อสอบถามข้อมูลและขั้นตอนการเข้ารับบริการ</p></div>
          <div className="contact-detail"><Clock3 size={21}/><div><strong>เวลาทำการ</strong><span>กรุณาตรวจสอบกับคลินิกก่อนเข้ารับบริการ</span></div></div>
          <div className="contact-detail"><UserRound size={21}/><div><strong>บัญชีผู้ใช้งาน</strong><span>{loading ? 'กำลังตรวจสอบ...' : session ? `เข้าสู่ระบบแล้ว: ${session.user.email}` : 'สมัครสมาชิกเพื่อเริ่มต้นใช้งาน'}</span></div></div>
        </section>
      </main>

      <footer className="site-footer"><a className="brand footer-brand" href="#home"><span className="brand-mark"><Bone size={22}/></span><span><strong>JointCare</strong><small>ORTHOPEDIC CLINIC</small></span></a><span>© {new Date().getFullYear()} JointCare. Starter project for learning.</span><span>CARE THAT MOVES WITH YOU</span></footer>

      {showAuth && <div className="modal-backdrop" onMouseDown={(event) => { if (event.target === event.currentTarget) setShowAuth(false); }}>
        <section className="auth-modal" role="dialog" aria-modal="true" aria-labelledby="auth-title">
          <button className="modal-close" onClick={() => setShowAuth(false)} aria-label="ปิด"><X size={20}/></button>
          <div className="modal-logo"><Bone size={26}/></div>
          <div className="eyebrow">WELCOME TO JOINTCARE</div>
          <h2 id="auth-title">{authMode === 'signup' ? 'สร้างบัญชีผู้ใช้' : 'ยินดีต้อนรับกลับมา'}</h2>
          <p>{authMode === 'signup' ? 'สมัครเพื่อเริ่มต้นใช้งานระบบ' : 'เข้าสู่ระบบด้วยบัญชีของคุณ'}</p>
          <form onSubmit={submitAuth}>
            {authMode === 'signup' && <label>ชื่อที่ใช้แสดง<input value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} required placeholder="ชื่อ-นามสกุล"/></label>}
            <label>อีเมล<input type="email" value={form.email} onChange={(e) => setForm({...form, email: e.target.value})} required placeholder="you@example.com" autoComplete="email"/></label>
            <label>รหัสผ่าน<input type="password" value={form.password} onChange={(e) => setForm({...form, password: e.target.value})} required minLength={6} placeholder="อย่างน้อย 6 ตัวอักษร" autoComplete={authMode === 'signup' ? 'new-password' : 'current-password'}/></label>
            <button className="btn btn-primary submit-btn" disabled={busy}>{busy ? 'กำลังดำเนินการ...' : authMode === 'signup' ? 'สมัครสมาชิก' : 'เข้าสู่ระบบ'} <ArrowRight size={17}/></button>
          </form>
          <div className="auth-switch">{authMode === 'signup' ? 'มีบัญชีอยู่แล้ว?' : 'ยังไม่มีบัญชี?'} <button onClick={() => setAuthMode(authMode === 'signup' ? 'login' : 'signup')}>{authMode === 'signup' ? 'เข้าสู่ระบบ' : 'สมัครสมาชิก'}</button></div>
          {!supabase && <p className="config-warning">ยังไม่ได้ตั้งค่า Supabase กรุณาทำตามขั้นตอนใน README.md</p>}
        </section>
      </div>}
    </div>
  );
}
