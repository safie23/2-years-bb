-- JointCare starter schema
-- Run in Supabase SQL Editor. Review and test all policies before real use.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'patient'
    check (role in ('patient', 'doctor', 'nurse', 'admin')),
  created_at timestamptz not null default now()
);

create table if not exists public.patients (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete set null,
  full_name text not null,
  phone text,
  birth_date date,
  created_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  patient_user_id uuid not null references auth.users(id) on delete cascade,
  doctor_name text,
  appointment_at timestamptz not null,
  visit_type text not null default 'onsite'
    check (visit_type in ('onsite', 'telemedicine')),
  status text not null default 'requested'
    check (status in ('requested', 'confirmed', 'cancelled', 'completed')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.patients enable row level security;
alter table public.appointments enable row level security;

-- A newly registered user receives a patient profile. The role is fixed to patient.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    'patient'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

grant select on public.profiles to authenticated;
grant update (full_name) on public.profiles to authenticated;
grant select, insert, update on public.patients to authenticated;
grant select, insert, update on public.appointments to authenticated;

drop policy if exists "Users can view own profile" on public.profiles;
create policy "Users can view own profile"
on public.profiles for select to authenticated
using ((select auth.uid()) = id);

drop policy if exists "Users can update own profile name" on public.profiles;
create policy "Users can update own profile name"
on public.profiles for update to authenticated
using ((select auth.uid()) = id)
with check ((select auth.uid()) = id);

drop policy if exists "Users can view own patient record" on public.patients;
create policy "Users can view own patient record"
on public.patients for select to authenticated
using ((select auth.uid()) = user_id);

drop policy if exists "Users can create own patient record" on public.patients;
create policy "Users can create own patient record"
on public.patients for insert to authenticated
with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update own patient record" on public.patients;
create policy "Users can update own patient record"
on public.patients for update to authenticated
using ((select auth.uid()) = user_id)
with check ((select auth.uid()) = user_id);

drop policy if exists "Users can view own appointments" on public.appointments;
create policy "Users can view own appointments"
on public.appointments for select to authenticated
using ((select auth.uid()) = patient_user_id);

drop policy if exists "Users can create own appointments" on public.appointments;
create policy "Users can create own appointments"
on public.appointments for insert to authenticated
with check ((select auth.uid()) = patient_user_id);

drop policy if exists "Users can update own appointments" on public.appointments;
create policy "Users can update own appointments"
on public.appointments for update to authenticated
using ((select auth.uid()) = patient_user_id)
with check ((select auth.uid()) = patient_user_id);

-- Important:
-- 1) These policies are for a learning starter and do not authorize staff workflows.
-- 2) Do not let users change their own role. Staff roles must be provisioned securely by an admin.
-- 3) Before production, review grants, policies, audit logs, backups, retention, and privacy requirements.
